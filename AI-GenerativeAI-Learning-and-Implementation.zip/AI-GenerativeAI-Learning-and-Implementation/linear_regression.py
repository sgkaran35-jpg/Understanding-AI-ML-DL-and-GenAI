# linear_regression.py
# Simple linear regression demo using scikit-learn on synthetic data.

import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split

def run_demo():
    # Create synthetic data: y = 4x + noise
    rng = np.random.RandomState(42)
    X = 2 * rng.rand(100, 1)
    y = 4 * X.ravel() + rng.randn(100) * 0.5

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=1)

    model = LinearRegression()
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)

    print('Learned coefficient:', model.coef_[0])
    print('Learned intercept:', model.intercept_)
    print('Test MSE:', mse)

    # Simple plot
    try:
        plt.scatter(X, y, label='data')
        x_line = np.linspace(0, 2, 100).reshape(-1, 1)
        plt.plot(x_line, model.predict(x_line), color='red', label='model')
        plt.legend()
        plt.title('Linear Regression Demo')
        plt.xlabel('X')
        plt.ylabel('y')
        plt.show()
    except Exception:
        # If running on headless server, skip plotting
        pass

if __name__ == '__main__':
    run_demo()

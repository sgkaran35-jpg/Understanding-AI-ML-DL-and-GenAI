# utils.py
# Small utility functions used by demos (kept minimal for clarity).

def print_header(title):
    print('\n' + '='*len(title))
    print(title)
    print('='*len(title) + '\n')

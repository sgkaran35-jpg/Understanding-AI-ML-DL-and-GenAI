# text_generation_gpt2.py
# Small text generation demo using Hugging Face transformers (GPT-2).
# Note: This downloads the GPT-2 model the first time you run it.

def run_demo(prompt=None, max_length=60):
    try:
        from transformers import pipeline, set_seed
    except Exception as e:
        print('Please install transformers (pip install transformers) and torch.')
        raise e

    gen = pipeline('text-generation', model='gpt2')
    set_seed(42)
    if prompt is None:
        prompt = 'In the near future, artificial intelligence will'

    outputs = gen(prompt, max_length=max_length, num_return_sequences=1)
    for i, out in enumerate(outputs):
        print('--- Generated text #{} ---'.format(i+1))
        print(out['generated_text'])

if __name__ == '__main__':
    run_demo()

# streamlit_app.py
# Small Streamlit app to run the demos from a web UI.
import streamlit as st
import subprocess
import sys

st.set_page_config(page_title='AI Demos', layout='centered')

st.title('AI & Generative AI – Demo Launcher')
st.markdown('Choose a demo and run it.')

demo = st.selectbox('Select demo', ['Linear Regression', 'Text Generation (GPT-2)', 'Summarization (T5)'])

if st.button('Run Demo'):
    if demo == 'Linear Regression':
        # Run linear_regression.py and capture output
        import linear_regression as lr
        lr.run_demo()
        st.success('Linear regression demo finished (check console or plot window).')
    elif demo == 'Text Generation (GPT-2)':
        import text_generation_gpt2 as tg
        tg.run_demo(prompt='Generative AI in 2025 will')
        st.success('Text generation finished (check console).')
    elif demo == 'Summarization (T5)':
        import summarizer as sm
        sm.run_demo()
        st.success('Summarization finished (check console).')

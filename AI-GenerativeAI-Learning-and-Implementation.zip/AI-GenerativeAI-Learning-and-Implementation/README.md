# AI-GenerativeAI-Learning-and-Implementation

This package contains ready-to-run example code files (simple demos) for:
- Linear regression (classical ML)
- Text generation using GPT-2 (transformers)
- Text summarization (transformers)
- A small Streamlit app to run demos locally

## How to use
1. Download the ZIP and extract.
2. Create a Python virtual environment and install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run simple demos:
   ```bash
   python linear_regression.py
   ```
4. To try the transformers-based demos (text gen / summarizer) run:
   ```bash
   python text_generation_gpt2.py
   python summarizer.py
   ```
   These use Hugging Face `transformers`. If you run locally, make sure you have internet access to download the model, or run in Google Colab.

5. To start the web demo (Streamlit):
   ```bash
   streamlit run streamlit_app.py
   ```

## Files included
- README.md (this file)
- requirements.txt
- linear_regression.py
- text_generation_gpt2.py
- summarizer.py
- streamlit_app.py
- utils.py

## Notes
- Transformers demos will download pretrained models (GPT-2, t5-small) when first run.
- If you want to use OpenAI or paid APIs, add your API key and adapt the code accordingly.
- This package is intended as a starter project for your YBI internship submission.

# summarizer.py
# Text summarization demo using Hugging Face transformers (t5-small).
# Note: First run downloads model weights.

def run_demo(text=None):
    try:
        from transformers import pipeline
    except Exception as e:
        print('Please install transformers (pip install transformers) and torch.')
        raise e

    summarizer = pipeline('summarization', model='t5-small')
    if text is None:
        text = (
            'Artificial intelligence (AI) is intelligence demonstrated by machines, '
            'in contrast to the natural intelligence displayed by humans and animals. '
            'Leading AI textbooks define the field as the study of "intelligent agents": '
            'any device that perceives its environment and takes actions that maximize '
            'its chance of successfully achieving its goals.'
        )

    summary = summarizer(text, max_length=60, min_length=10, do_sample=False)
    print('Original text:')
    print(text)
    print('\nSummary:')
    print(summary[0]['summary_text'])

if __name__ == '__main__':
    run_demo()
